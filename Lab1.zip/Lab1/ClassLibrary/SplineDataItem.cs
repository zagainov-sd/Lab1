﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public delegate double FRaw(double x);
    public enum FRawEnum {linear, cubic, rand};

    
    public class SplineDataItem
    {
        public double dot { get; set; }
        public double value { get; set; }
        public double first_derivative {get; set; }
        public double second_derivative {get; set; }
        
        public SplineDataItem(double _dot, double _value, double _first_derivative, double _second_derivative)
        {
            dot = _dot;
            value = _value;
            first_derivative = _first_derivative;
            second_derivative = _second_derivative;
        }
        public string ToString(string format)
        {
            string rez = string.Empty;
            rez += "Координата точки: " + String.Format(format, dot) + "\n";
            rez += "Значение сплайна: " + String.Format(format, value) + "\n";
            rez += "Значение первой производной: " + String.Format(format, first_derivative) + "\n";
            rez += "Значение второй производной: " + String.Format(format, second_derivative) + "\n";
            return rez;
        }
        public override string ToString()
        {
            return ToString("{0:F}");
        }
    }
}
