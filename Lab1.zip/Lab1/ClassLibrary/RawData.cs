﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class RawData
    {
        public double a;
        public double b;
        public int amount_grid;
        public bool is_uniform_grid;
        public FRaw fraw;
        public double[] nodes;
        public double[] values;

        public RawData(double _a, double _b, int _amount_grid, bool _is_uniform_grid, FRaw _fraw)
        {
            this.a = _a;
            this.b = _b;
            this.amount_grid = _amount_grid;
            this.is_uniform_grid = _is_uniform_grid;
            this.fraw = _fraw;
            //nodes = new double[amount];
        }
        public RawData(string filename)
        {
            FileStream fs = null;
            try
            {
                fs = new FileStream(filename, FileMode.Open);
                StreamReader streamreader = new StreamReader(fs);
                this.a = Convert.ToDouble(streamreader.ReadLine());
                this.b = Convert.ToDouble(streamreader.ReadLine());
                this.amount_grid = Convert.ToInt32(streamreader.ReadLine());
                this.is_uniform_grid = Convert.ToBoolean(streamreader.ReadLine());
                string func_type = streamreader.ReadLine();
                if (func_type == "linear") this.fraw = linear;
                else if (func_type == "cubic") this.fraw = cubic;
                else this.fraw = rand;

                nodes = new double[amount_grid];
                values = new double[amount_grid];
                string[] values_str = streamreader.ReadLine().Split(" ");
                for (int i = 0; i < amount_grid; i++)
                {
                    nodes[i] = Convert.ToDouble(values_str[i]);
                    values[i] = fraw(nodes[i]);
                }
                streamreader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            finally
            {
                if (fs != null) fs.Close();
            }
        }
        static public double linear(double x)
        {
            return x;
        }
        static public double cubic(double x)
        {
            return x * x * x;
        }
        static public double rand(double x)
        {
            Random rnd = new Random();
            return rnd.NextDouble() * x;
        }

        public void Save(string filename)
        {
            FileStream fs = null;
            try
            {
                fs = new FileStream(filename, FileMode.Create);
                StreamWriter streamwriter = new StreamWriter(fs);
                streamwriter.WriteLine($"a = {this.a}");
                streamwriter.WriteLine($"b = {this.b}");
                streamwriter.WriteLine($"amount_grid = {this.amount_grid}");
                streamwriter.WriteLine($"is_uniform_grid = {this.is_uniform_grid}");

                if(this.fraw == linear) streamwriter.WriteLine("function: linear");
                else if (this.fraw == cubic) streamwriter.WriteLine("function: cubic");
                else streamwriter.WriteLine("function: random");

                for (int i = 0; i < amount_grid; i++) //nodes.Length
                {
                    streamwriter.WriteLine($"node = {this.nodes[i]}, value = {this.values[i]}");
                }
                streamwriter.Close();
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                throw;
            }
            finally
            {
                if (fs != null) fs.Close();
            }
        }
        public static void Load(string filename, out RawData rawData)
        {
            try
            {
                rawData = new RawData(filename);
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
