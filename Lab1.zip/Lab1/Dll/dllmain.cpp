﻿// dllmain.cpp : Определяет точку входа для приложения DLL.
#include "pch.h"
#include "mkl.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}


extern "C" _declspec(dllexport) void make_spline(double *function_values, bool is_uniform_grid, int amount_grid, double *grid_if_uniform, double *grid_if_nonuniform, double *derivative2, int dots_amount, double *values, double *left_intergate_lim, double *right_intergate_lim, double *integrals, int &ret_error_code)
{
    DFTaskPtr task;
    int error_code = DF_STATUS_OK;
    if (is_uniform_grid)
    {
        error_code = dfdNewTask1D(&task, amount_grid, grid_if_uniform, DF_UNIFORM_PARTITION, 1, function_values, DF_MATRIX_STORAGE_ROWS);
        if (error_code != DF_STATUS_OK)
        {
            ret_error_code = error_code;
            return;
        }
    }
    else
    {
        error_code = dfdNewTask1D(&task, amount_grid, grid_if_nonuniform, DF_NON_UNIFORM_PARTITION, 1, function_values, DF_MATRIX_STORAGE_ROWS);
        if (error_code != DF_STATUS_OK)
        {
            ret_error_code = error_code;
            return;
        }
    }
    double *coefs = new double[1 * 4 * (amount_grid - 1)];
    error_code = dfdEditPPSpline1D(task, DF_PP_CUBIC, DF_PP_NATURAL, DF_BC_2ND_LEFT_DER | DF_BC_2ND_RIGHT_DER, derivative2, DF_NO_IC, NULL, coefs, DF_NO_HINT);
    if (error_code != DF_STATUS_OK)
    {
        ret_error_code = error_code;
        return;
    }
    error_code = dfdConstruct1D(task, DF_PP_SPLINE, DF_METHOD_STD);
    if (error_code != DF_STATUS_OK)
    {
        ret_error_code = error_code;
        return;
    }
    int dorder[3]{ 1, 1, 1 };
    error_code = dfdInterpolate1D(task, DF_INTERP, DF_METHOD_PP, dots_amount, grid_if_uniform, DF_UNIFORM_PARTITION, 3, dorder, NULL, values, DF_MATRIX_STORAGE_ROWS, NULL);
    if (error_code != DF_STATUS_OK)
    {
        ret_error_code = error_code;
        return;
    }
    error_code = dfdIntegrate1D(task, DF_METHOD_PP, 1, left_intergate_lim, DF_NON_UNIFORM_PARTITION, right_intergate_lim, DF_NON_UNIFORM_PARTITION, NULL, NULL, integrals, DF_MATRIX_STORAGE_ROWS);
    if (error_code != DF_STATUS_OK)
    {
        ret_error_code = error_code;
        return;
    }
    error_code = dfDeleteTask(&task);
    if (error_code != DF_STATUS_OK)
    {
        ret_error_code = error_code;
        return;
    }
}
