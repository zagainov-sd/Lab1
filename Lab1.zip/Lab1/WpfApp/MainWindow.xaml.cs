﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;
using Microsoft.Win32;

namespace WpfApp
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ViewData viewData = new ViewData();
        string format = "{0:F}";
        public MainWindow()
        {
            InitializeComponent();
        
            this.DataContext = viewData;
            combobox_fraw.ItemsSource = Enum.GetValues(typeof(ClassLibrary.FRawEnum));
        }

        private void button_save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();

            if(dlg.ShowDialog() == true)
            {
                viewData.Save(dlg.FileName);
            }
        }
        private void to_listbox_rowdata()
        {
            listbox_rowdata.Items.Clear();
            for (int i = 0; i < viewData.rawdata.amount_grid; i++)
            {
                string rez = string.Empty;

                rez += "Значение в узле: " + String.Format(format, viewData.rawdata.nodes[i]) + " ";
                rez += "Значение функции в узле: " + String.Format(format, viewData.rawdata.values[i]) + "\n";

                listbox_rowdata.Items.Add(rez);
            }
        }
        private void button_open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == true)
            {
                viewData.Load(dlg.FileName);
                viewData.ExecuteSplines_open();
                to_listbox_rowdata();

                listbox_splinedata.ItemsSource = viewData.splinedata.list;

                textblock_integral.Text = viewData.splinedata.integral_value.ToString();
            }
        }
        
        private void button_execute_Click(object sender, RoutedEventArgs e)
        {
            viewData.ExecuteSplines();
            to_listbox_rowdata();

            listbox_splinedata.ItemsSource = viewData.splinedata.list;

            textblock_integral.Text = viewData.splinedata.integral_value.ToString();
        }

        private void listbox_splinedata_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SplineDataItem? item = listbox_splinedata.SelectedItem as SplineDataItem;
            if (item != null) textblock_selected.Text = item.ToString(format);
        }
    }
}
