﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows;

namespace WpfApp
{
    internal class Grid_converter: IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {
                string? dir2_left = values[0].ToString();
                string? dir2_right = values[1].ToString();
                if (dir2_left == null || dir2_right == null) throw new ArgumentNullException();
                return dir2_left + " ; " + dir2_right;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            try
            {
                string? str = value as string;
                if (str == null) throw new ArgumentNullException();
                string[] s = str.Split(";", StringSplitOptions.RemoveEmptyEntries);
                return new object[] { System.Convert.ToDouble(s[0]), System.Convert.ToDouble(s[1]) };
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
    }
}
